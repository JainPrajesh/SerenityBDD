package devops.serenity;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;

import devops.utils.TestUtils;
import net.serenitybdd.core.annotations.findby.FindBy;
import net.serenitybdd.core.pages.PageObject;
import net.thucydides.core.annotations.Step;

public class iRobot_HomePage extends PageObject {

	TestUtils tUtil = new TestUtils();
	private boolean isPresent;
	
	String tabXpath;
	String productXpath;
	String categoryXpath;
	WebElement navTab;
	WebElement navCategory;
	WebElement productBtn;
	
	@FindBy(xpath = "//button[@class='optanon-allow-all accept-cookies-button']")
	private WebElement cookie;

	
	// Home page navigation

	@Step("Opening the web page")
	public void openPage(String location) throws InterruptedException {
		getDriver().manage().window().maximize();

		switch (location) {

		case "Belgium(FR)":
			getDriver().get("http://staging-na02-irobot.demandware.net/s/iRobotEMEA/home?lang=fr_BE");
			System.out.println("Location :" + location);
			break;

		case "Canada":
			System.out.println("Location :" + location);
			getDriver().get("https://staging-na02-irobot.demandware.net/on/demandware.store/Sites-iRobotCA-Site");
			break;

		case "Denmark":
			getDriver().get("http://staging-na02-irobot.demandware.net/s/iRobotEMEA/home?lang=da_DK");
			System.out.println("Location :" + location);
			break;

		case "France":
			getDriver().get("http://staging-na02-irobot.demandware.net/s/iRobotEMEA/home?lang=fr_FR");
			System.out.println("Location :" + location);
			break;

		case "Germany":
			getDriver().get("https://staging-na02-irobot.demandware.net/s/iRobotEMEA/home?lang=de_DE");
			System.out.println("Location :" + location);
			break;

		case "Ireland":
			getDriver().get("https://staging-na02-irobot.demandware.net/s/iRobotEMEA/home?lang=en_IE");
			System.out.println("Location :" + location);
			break;

		case "Netherland":
			getDriver().get("http://staging-na02-irobot.demandware.net/s/iRobotEMEA/home?lang=nl_NL");
			System.out.println("Location :" + location);
			break;

		case "Portugal":
			getDriver().get("http://staging-na02-irobot.demandware.net/s/iRobotEMEA/home?lang=pt_PT");
			System.out.println("Location :" + location);
			break;

		case "Spain":
			getDriver().get("http://staging-na02-irobot.demandware.net/s/iRobotEMEA/home?lang=es_ES");
			System.out.println("Location :" + location);
			break;

		case "Sweden":
			getDriver().get("http://staging-na02-irobot.demandware.net/s/iRobotEMEA/home?lang=sv_SE");
			System.out.println("Location :" + location);
			break;

		case "USA":
			System.out.println("Location :" + location);
			getDriver().get("https://www.irobot.com/");
			break;

		case "UK":
			getDriver().get("https://staging-na02-irobot.demandware.net/s/iRobotEMEA/home?lang=en_GB");
			System.out.println("Location :" + location);
			break;

		default:
			System.out.println("Running on default Env");
			getDriver().get("https://staging-na02-irobot.demandware.net/s/iRobotNA/default/home");

		}
	}

	// Select product and product category on home page
	@Step("Product Selection")
	public void selProduct(String tab, String category, String product, String location) throws InterruptedException {
		String tabXpath;
		String productXpath;
		String categoryXpath;
		WebElement navTab;
		WebElement navCategory;
		WebElement productBtn;

		switch (location) {

		case "Belgium(FR)":
			System.out.println("Location :" + location);
			navTab = getDriver()
					.findElement(By.xpath("//a[@class='a-link a-link--nav'][contains(text(),'" + tab + "')]"));
			navTab.click();
			navCategory = getDriver().findElement(By.xpath("//a[contains(text(),'" + category + "')]"));
			navCategory.click();
			break;

		case "Canada":
			System.out.println("Location :" + location);
			navTab = getDriver()
					.findElement(By.xpath("//a[@class='a-link a-link--nav'][contains(text(),'" + tab + "')]"));
			navTab.click();
			navCategory = getDriver().findElement(By.xpath("//a[contains(text(),'" + category + "')]"));
			navCategory.click();
			break;

		case "Denmark":
			System.out.println("Location :" + location);
			navTab = getDriver()
					.findElement(By.xpath("//a[@class='a-link a-link--nav'][contains(text(),'" + tab + "')]"));
			navTab.click();
			navCategory = getDriver().findElement(By.xpath("//a[contains(text(),'" + category + "')]"));
			navCategory.click();
			break;

		case "France":
			System.out.println("Location :" + location);
			navTab = getDriver()
					.findElement(By.xpath("//a[@class='a-link a-link--nav'][contains(text(),'" + tab + "')]"));
			navTab.click();
			navCategory = getDriver().findElement(By.xpath("//a[contains(text(),'" + category + "')]"));
			navCategory.click();
			break;

		case "Germany":
			System.out.println("Location :" + location);
			navTab = getDriver()
					.findElement(By.xpath("//a[@class='a-link a-link--nav'][contains(text(),'" + tab + "')]"));
			navTab.click();
			navCategory = getDriver().findElement(By.xpath("//a[contains(text(),'" + category + "')]"));
			navCategory.click();
			break;

		case "Ireland":
			System.out.println("Location :" + location);
			navTab = getDriver()
					.findElement(By.xpath("//a[@class='a-link a-link--nav'][contains(text(),'" + tab + "')]"));
			navTab.click();
			navCategory = getDriver().findElement(By.xpath("//a[contains(text(),'" + category + "')]"));
			navCategory.click();
			break;

		case "Netherland":
			System.out.println("Location :" + location);
			navTab = getDriver()
					.findElement(By.xpath("//a[@class='a-link a-link--nav'][contains(text(),'" + tab + "')]"));
			navTab.click();
			navCategory = getDriver().findElement(By.xpath("//a[contains(text(),'" + category + "')]"));
			navCategory.click();
			break;

		case "Spain":
			System.out.println("Location :" + location);
			tabXpath = "//a[@class='a-link a-link--nav'][contains(text(),'" + tab + "')]";
			categoryXpath = "//a[contains(text(),'" + category + "')]";
			productXpath = "//h3[text()='" + product
					+ "']/parent::div[@class='o-product-lineup__featuredcard--upper']/following-sibling::div[@class='o-product-lineup__featuredcard--lower']//a[1]";

			navTab = getDriver().findElement(By.xpath(tabXpath));
			navCategory = getDriver().findElement(By.xpath(categoryXpath));
			productBtn = getDriver().findElement(By.xpath(productXpath));
			// click on the product of category vacuums
			withAction().moveToElement(element(navTab)).moveToElement(element(navCategory)).click().build().perform();
			waitFor(ExpectedConditions.elementToBeClickable(productBtn));
			break;

		case "Sweden":
			System.out.println("Location :" + location);
			navTab = getDriver()
					.findElement(By.xpath("//a[@class='a-link a-link--nav'][contains(text(),'" + tab + "')]"));
			navTab.click();
			navCategory = getDriver().findElement(By.xpath("//a[contains(text(),'" + category + "')]"));
			navCategory.click();
			break;

		case "USA":
			System.out.println("Location :" + location);
			navTab = getDriver()
					.findElement(By.xpath("//a[@class='a-link a-link--nav'][contains(text(),'" + tab + "')]"));
			navTab.click();
			navCategory = getDriver().findElement(By.xpath("//a[contains(text(),'" + category + "')]"));
			navCategory.click();
			break;

		case "UK":
			System.out.println("Location :" + location);
			navTab = getDriver()
					.findElement(By.xpath("//a[@class='a-link a-link--nav'][contains(text(),'" + tab + "')]"));
			navTab.click();
			navCategory = getDriver().findElement(By.xpath("//a[contains(text(),'" + category + "')]"));
			navCategory.click();
			break;

		}
	}

	public void countrySelector(String country) throws InterruptedException {
		WebElement countrySelectorIcon;
		WebElement countryName;
		countrySelectorIcon = getDriver().findElement(By.xpath(
				"//body/div[@class='o-headercontainer']/div[@class='o-header']/div[@class='o-header__container']/div[@class='o-header__rightheader u-desktop-only']/div[1]/a[1]"));
		countrySelectorIcon.click();
		Thread.sleep(2000);
		countryName = getDriver().findElement(By.xpath(
				"//div[@class='m-iconWithDropdown__dropdowncontainer active']//p[@class='m-iconWithDropdown__name'][contains(text(),'"
						+ country + "')]"));

		withAction().moveToElement(element(countrySelectorIcon)).moveToElement(element(countryName)).click().perform();
	}

	public void footerEmailSignUp(String email) throws InterruptedException {

		WebElement emailXpath;
		emailXpath = getDriver().findElement(By.xpath("//input[@id='field0']"));
		emailXpath.sendKeys(email);
		emailXpath.sendKeys(Keys.ENTER);
		Thread.sleep(2000);
	}

	public void emailSignUpTerra(String email) throws InterruptedException {

		WebElement emailXpath;
		emailXpath = getDriver().findElement(By.xpath("//div[@class='text-block']//div//input[@id='field0']"));
		emailXpath.sendKeys(email);
		emailXpath.sendKeys(Keys.ENTER);
		Thread.sleep(2000);
	}

	public void search(String searchText) throws InterruptedException {

		WebElement searchIcon;
		WebElement searchInputBox;

		searchIcon = getDriver().findElement(
				By.xpath("//div[@class='o-header__rightheader u-desktop-only']//a[@class='a-icon fa fa-search']"));

		searchIcon.click();
		searchInputBox = getDriver()
				.findElement(By.xpath("//div[@class='m-iconWithDropdown__dropdowncontainer active']//div//div//input"));
		// div[@class='m-iconWithDropdown__dropdowncontainer
		// active']//div//div//input[@placeholder='search']
		waitFor(ExpectedConditions.elementToBeClickable(searchInputBox));
		searchInputBox.sendKeys(searchText);
		Thread.sleep(2000);
	}

	public void verifySearchList() throws InterruptedException {

		isPresent = false;
		if (getDriver().findElement(By.xpath("//div[@class='m-iconWithDropdown u-desktop-only']//div[4]"))
				.getSize() != null) {

			System.out.println("element is present");
			isPresent = true;
		} else {
			System.out.println("element not present");
		}

		Assert.assertTrue(isPresent);
	}
	
	
	public void compareProducts(String tab, String product, String location ) throws InterruptedException {
		
		System.out.println("Location :" + location);
		System.out.println("Location :" + location);
		navTab = getDriver()
				.findElement(By.xpath("//a[@class='a-link a-link--nav'][contains(text(),'" + tab + "')]"));
		navTab.click();
		
		cookie.click();
		Thread.sleep(2000);
		productBtn = getDriver()
				.findElement(By.xpath("//a[contains(text(), '"+ product +"')]"));
		productBtn.click();
		 
		
	}
	
	public void miniCart() throws InterruptedException {

		isPresent = false;
		if (getDriver().findElement(By.xpath("//div[@class='m-iconWithDropdown__dropdowncontainer active']//div[@class='m-iconWithDropdown__cartItemDetails']"))
				.getSize() != null) {

			System.out.println("element is present");
			isPresent = true;
		} else {
			System.out.println("element not present");
		}

		Assert.assertTrue(isPresent);
	}

}
