package devops.serenity;

import org.junit.Assert;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;

import devops.utils.TestUtils;
import net.serenitybdd.core.annotations.findby.FindBy;
import net.serenitybdd.core.pages.PageObject;
import net.thucydides.core.annotations.Step;

public class iRobot_ViewCartPage extends PageObject{
	
TestUtils tUtil = new TestUtils();

	@FindBy(xpath = "//a[@class='optanon-allow-all']")
	private WebElement cookie;

	@FindBy(xpath = "//input[@id='dwfrm_cart_couponCode']")
	private WebElement couponCodeInputBox;
	
	@FindBy(xpath = "//button[@id='add-coupon']")
	private WebElement applyBtn;
	
	@FindBy(xpath = "//div[@class='cart-coupon-code large-up-show']//div[@class='error'][contains(text(),'Coupon code \"1234\" is unknown.')]")
	private WebElement appliedCpnMsg;
	
	@FindBy(xpath = "//div[@class='cart-actions']//button[@name='dwfrm_cart_checkoutCart']")
	private WebElement cartCheckoutBtn;
	
	@Step("apply coupon")
	public void applyCoupon(String promoCode) throws InterruptedException {
		Thread.sleep(3000);
		cookie.click();
		waitFor(ExpectedConditions.elementToBeClickable(couponCodeInputBox));
		Thread.sleep(3000);
		System.out.println("Applying Coupon");
		couponCodeInputBox.clear();
		couponCodeInputBox.sendKeys(promoCode);
		applyBtn.click();
		
	}
	
	@Step("Checkout @viewCart page")
	public void cartCheckout() throws InterruptedException {
		Thread.sleep(3000);
		waitFor(ExpectedConditions.elementToBeClickable(cartCheckoutBtn));
		cartCheckoutBtn.click();
	}
	
	@Step("Verify success message on applying the coupon code")
	public void verifySuccessMessage() throws InterruptedException {
		Thread.sleep(3000);
		cookie.click();
		//verify message is displayed when a wrong coupon is applied
		Assert.assertFalse("Coupon code \"1234\" is unknown.", false);
	
	}
}
