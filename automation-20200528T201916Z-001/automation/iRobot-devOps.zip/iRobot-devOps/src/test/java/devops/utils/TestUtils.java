package devops.utils;

import static org.junit.Assert.assertEquals;

import java.util.HashMap;
import java.util.Map;
import java.util.Random;

import org.apache.commons.codec.binary.Base64;

import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;

public class TestUtils {
	static Map<String,String> jwtTokenDecoded = new HashMap<String,String>();

	public static String getRandomValue(){
		Random random = new Random();
		int radomInt = random.nextInt(100000);
		return Integer.toString(radomInt);
	}
	
	 public  Map<String, String> testDecodeJWT(String token){
	        String jwtToken = token;
	        System.out.println("------------ Decode JWT ------------");
	        String[] split_string = jwtToken.split("\\.");
	        String base64EncodedHeader = split_string[0];
	        String base64EncodedBody = split_string[1];
	        String base64EncodedSignature = split_string[2];

	        System.out.println("~~~~~~~~~ JWT Header ~~~~~~~");
	        Base64 base64Url = new Base64(true);
	        String header = new String(base64Url.decode(base64EncodedHeader));
	        System.out.println("JWT Header : " + header);
	        jwtTokenDecoded.put("jwtTokenHeader", header);

	        System.out.println("~~~~~~~~~ JWT Body ~~~~~~~");
	        String body = new String(base64Url.decode(base64EncodedBody));
	        System.out.println("JWT Body : "+body); 
	        jwtTokenDecoded.put("jwtTokenBody", body);
	       
	        return jwtTokenDecoded; 
	    }
	
	public String returnToken(Response res) {
		JsonPath jsonPathEvaluator = res.jsonPath();
		String token = jsonPathEvaluator.get("data.sessionToken");
	    
	    System.out.println(token);
		return token;
	}
	
	public void verifyStatus(Response res) {
		int code = res.getStatusCode();
        assertEquals(200, code);		
		System.out.println(code);
	}
	
    public void verifyResponseUri_AllowValue(Response res, String Uri, Boolean Allow_value) {
		
		String article = null;
		Boolean value = null;
		
		JsonPath jsonPathEvaluator = res.jsonPath();
		article = jsonPathEvaluator.get("data.accessRights.uri");
		value = jsonPathEvaluator.get("data.accessRights.allow");
		
		System.out.println(article + "" + value);
		
		assertEquals(Uri, article);
		assertEquals(Allow_value, value);
		}
}
