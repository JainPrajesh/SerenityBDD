package devops.serenity;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import net.serenitybdd.core.annotations.findby.FindBy;
import net.serenitybdd.core.pages.PageObject;
import net.thucydides.core.annotations.Step;

public class iRobot_AccessoriesPage extends PageObject{
	
	// accept cookie xpath
		@FindBy(xpath = "//a[@class='optanon-allow-all']")
		private WebElement cookie;
		
		//xpath for accessories tag
		
		@FindBy(xpath = "//span[contains(text(),'Parts & Accessories')]")
		private WebElement accessory;
		// *****************************************************************************************************//
		
		@Step("Product Category Selection")
		public void selProductCategory(String productCtg) throws InterruptedException {
			Thread.sleep(2000);
			String xPath = "//a[@class='subcat-top-link'][contains(text(),'"+productCtg+"')]";
			WebElement productCtgElement = getDriver().findElement(By.xpath(xPath));
			productCtgElement.click();
		}
		
		@Step("Select Accessory")
		public void selectAccessory(String accessory) throws InterruptedException {
			Thread.sleep(5000); 
			cookie.click();
			String xPath = "//a[contains(text(),'"+accessory+"')]";
			WebElement accessoryElement = getDriver().findElement(By.xpath(xPath));
			accessoryElement.click();
			
		}
}
