package devops.serenity;
import devops.utils.TestUtils;

import org.junit.Assert;
import net.serenitybdd.core.pages.PageObject;
import net.thucydides.core.annotations.Step;

public class ProductVerificationPage extends PageObject {
	
	TestUtils tUtil = new TestUtils();
	
	private boolean expected_title;
	private boolean actual_title;
	
	@Step("verify the title of the page")
	public void VerifyTitle(String title) throws InterruptedException {
		expected_title = getDriver().getTitle().contains(title);
		actual_title = true;
		System.out.println("expected_title: " +expected_title);
		Assert.assertEquals("title doesn't match",actual_title, expected_title);
		 
		
	}
	
}
