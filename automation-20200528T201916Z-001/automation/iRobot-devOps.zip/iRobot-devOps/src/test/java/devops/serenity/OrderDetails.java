package devops.serenity;

import java.util.ArrayList;
import net.serenitybdd.core.pages.PageObject;
public class OrderDetails extends PageObject {
	
	ArrayList<String> orderNo;
	ArrayList<String> subTotal;
	ArrayList<String> tax;
	ArrayList<String> pymttType;
	ArrayList<String> pymtInfo;
	ArrayList<String> shippingAdd;
	
	public ArrayList<String> getOrderNo() {
		return orderNo;
	}
	public void setOrderNo(ArrayList<String> orderNo) {
		this.orderNo = orderNo;
	}
	public ArrayList<String> getSubTotal() {
		return subTotal;
	}
	public void setSubTotal(ArrayList<String> subTotal) {
		this.subTotal = subTotal;
	}
	public ArrayList<String> getTax() {
		return tax;
	}
	public void setTax(ArrayList<String> tax) {
		this.tax = tax;
	}
	public ArrayList<String> getPymttType() {
		return pymttType;
	}
	public void setPymttType(ArrayList<String> pymttType) {
		this.pymttType = pymttType;
	}
	public ArrayList<String> getPymtInfo() {
		return pymtInfo;
	}
	public void setPymtInfo(ArrayList<String> pymtInfo) {
		this.pymtInfo = pymtInfo;
	}
	public ArrayList<String> getShippingAdd() {
		return shippingAdd;
	}
	public void setShippingAdd(ArrayList<String> shippingAdd) {
		this.shippingAdd = shippingAdd;
	}
}
