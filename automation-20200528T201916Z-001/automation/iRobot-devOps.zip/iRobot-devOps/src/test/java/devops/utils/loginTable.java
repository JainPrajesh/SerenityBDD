package devops.utils;


public class loginTable {
	public String email;
	public String password;
	
	
	public loginTable (String eml, String pass) 
	{
		email = eml;
		password = pass;
	}
}
