package devops.testbase;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.junit.BeforeClass;

import cucumber.api.Scenario;
import cucumber.api.java.Before;
import net.thucydides.core.util.EnvironmentVariables;
import net.thucydides.core.util.SystemEnvironmentVariables;

public class TestBase {

	public boolean FAIL = false;
	static boolean tagName = false;
	Map<String, Integer> mapB = new HashMap<String, Integer>();
	Map<Integer, List<Integer>> mapStep = new HashMap<Integer, List<Integer>>();

	List<Integer> rId;
	List<String> rSummary;
	List<Integer> sId;
	EnvironmentVariables var = SystemEnvironmentVariables.createEnvironmentVariables();

	@BeforeClass
	public static void init() throws IOException {

	}

	@Before
	public void before(Scenario scenario) {
		String sName = scenario.getName();
		System.out.println("Current Scenario : " + sName);
	}

}
