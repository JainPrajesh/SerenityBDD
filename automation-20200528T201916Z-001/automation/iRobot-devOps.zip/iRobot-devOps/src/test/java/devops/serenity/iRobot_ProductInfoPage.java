package devops.serenity;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;

import devops.utils.TestUtils;
import net.serenitybdd.core.annotations.findby.FindBy;
import net.serenitybdd.core.pages.PageObject;
import net.thucydides.core.annotations.Step;

public class iRobot_ProductInfoPage extends PageObject {

	TestUtils tUtil = new TestUtils();

	@FindBy(xpath = "//button[@class='optanon-allow-all accept-cookies-button']")
	private WebElement cookie;

	@FindBy(id = "Quantity")
	private WebElement selQuantity;

	@FindBy(xpath = "//button[@id='add-to-cart']")
	private WebElement addCartBtn;

	@FindBy(xpath = "//div[@class='o-header__rightheader u-desktop-only']//a[@class='a-link a-link--cart']")
	private WebElement cartBtn;

	@FindBy(xpath = "//*[contains(@class,'icon shopping-cart')]")
	private WebElement cartIcon;

	@FindBy(xpath = "//a[@class='button mini-cart-link-cart']")
	private WebElement viewCartBtn;

	// NEW MINI CART CHECKOUT XPATH FOR NEW FXM HEADER
	// div[@class='o-header__rightheader u-desktop-only']//i[@class='a-icon fas
	// fa-shopping-cart']
	@FindBy(xpath = "//a[@class='mini-cart-link-checkout']")
	private WebElement checkout;

	@FindBy(xpath = "//input[@id='gigya-loginID-111298689147766560']")
	private WebElement email;

	@FindBy(xpath = "//input[@id='gigya-password-17588167012738688']")
	private WebElement password;

	@FindBy(xpath = "//form[@id='gigya-login-form']//input[@class='gigya-input-submit']")
	private WebElement submitLogin;

	@FindBy(xpath = "//button[@name='dwfrm_login_unregistered']")
	private WebElement checkoutGuestBtn;
	
	String productXpath;
	WebElement productBtn;
	
	
	@Step("add Product")
	public void addProduct(String product) throws InterruptedException {
		productXpath = "//h3[text()='" + product
				+ "']/parent::div[@class='o-product-lineup__featuredcard--upper']/following-sibling::div[@class='o-product-lineup__featuredcard--lower']//a[1]";

		productBtn = getDriver().findElement(By.xpath(productXpath));
		// click on the product of category vacuums
		Thread.sleep(2000);
		cookie.click();
		productBtn.click();
	}
	
	
	
	
	@Step("Select Quantity")
	public void selQuantity(String value) throws InterruptedException {
		Thread.sleep(3000);
		cookie.click();
		element(selQuantity).selectByValue(value);
		// withAction().moveToElement(addCartBtn).click().perform();
		addCartBtn.click();
	}

	@Step("Checkout navigation")
	public void proceedCheckout() throws InterruptedException {
		// waitFor(ExpectedConditions.elementToBeClickable(cartBtn));
		// cartBtn.click();
		Thread.sleep(3000);
		System.out.println(checkout);
		checkout.click();

	}

	@Step("Checkout guest")
	public void guestCheckout() throws InterruptedException {
		waitFor(ExpectedConditions.elementToBeClickable(checkoutGuestBtn));
		checkoutGuestBtn.click();
	}

	@Step("Hide mini cart checkout")
	public void hideMiniCart() throws InterruptedException {
		waitFor(ExpectedConditions.elementToBeClickable(cartIcon));
		cartIcon.click();
		Thread.sleep(2000);
	}

	@Step("View Cart")
	public void clkViewCart() throws InterruptedException {
		waitFor(ExpectedConditions.elementToBeClickable(viewCartBtn));
		viewCartBtn.click();
	}

	@Step("Login info")
	public void loginReturningCust(String eml, String pass) throws InterruptedException {
		waitFor(ExpectedConditions.elementToBeClickable(email));
		email.clear();
		email.sendKeys(eml);
		password.clear();
		password.sendKeys(pass);
		submitLogin.click();
	}
}
