package devops.cucumber;
import org.junit.runner.RunWith;

import cucumber.api.CucumberOptions;
import devops.testbase.TestBase;
import net.serenitybdd.cucumber.CucumberWithSerenity;


@RunWith(CucumberWithSerenity.class)
@CucumberOptions(
features = {"src/test/resources/feature/"},
glue = { "devops.cucumber.steps","devops.testbase","devops.utils"},
plugin = {"pretty"})

public class Runner extends TestBase{

	
}
