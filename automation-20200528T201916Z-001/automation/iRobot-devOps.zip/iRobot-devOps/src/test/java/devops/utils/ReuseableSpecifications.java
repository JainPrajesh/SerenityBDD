package devops.utils;

import io.restassured.RestAssured;
import io.restassured.builder.RequestSpecBuilder;
import io.restassured.builder.ResponseSpecBuilder;
import io.restassured.http.ContentType;
import io.restassured.specification.RequestSpecification;
import io.restassured.specification.ResponseSpecification;
import net.thucydides.core.util.EnvironmentVariables;
import net.thucydides.core.util.SystemEnvironmentVariables;

import static org.hamcrest.Matchers.*;

import java.net.URI;
import java.util.concurrent.TimeUnit;

public class ReuseableSpecifications {
	
	
	static EnvironmentVariables variables = SystemEnvironmentVariables.createEnvironmentVariables();
 	public static ResponseSpecBuilder respec;
 	public static ResponseSpecification responseSpecification;
	static String username = variables.getProperty("jira.username").trim();
	static String password = variables.getProperty("jira.password").trim();
	public static RequestSpecBuilder rspec;
	public static RequestSpecification requestSpecification;
	


	
	public static RequestSpecification getGenericRequestSpec(){
		
		rspec = new RequestSpecBuilder();
		rspec.setContentType(ContentType.JSON);
		requestSpecification = rspec.build();
		return requestSpecification;
		
	}
	
	 public static RequestSpecification getGenericJiraRequestSpec(){
		 		
		 		rspec = new RequestSpecBuilder();
		 		rspec.setContentType(ContentType.JSON);
		 		rspec.setAuth(RestAssured.preemptive().basic(username, password));
		 		rspec.addHeader("X-Atlassian-Token","no-check");
		 		requestSpecification = rspec.build();
		 		return requestSpecification;
		 		
		 	}
	
	
	public static RequestSpecification getGenericRequestSpec(URI url){
	
		requestSpecification = new RequestSpecBuilder().setBaseUri(url).build();
		rspec.setContentType(ContentType.JSON);
		requestSpecification = rspec.build();
		return requestSpecification;
		
	}
	
	public static ResponseSpecification getGenericResponseSpec(){
		respec = new ResponseSpecBuilder();
		respec.expectHeader("Content-Type","application/json;charset=UTF-8");
		respec.expectHeader("Transfer-Encoding","chunked");
		respec.expectResponseTime(lessThan(5L),TimeUnit.SECONDS);
		responseSpecification = respec.build();
		return responseSpecification;
		
	}
}
