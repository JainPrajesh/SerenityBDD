package devops.cucumber.steps;

import java.util.ArrayList;
import java.util.List;
import org.openqa.selenium.WebDriver;

import cucumber.api.DataTable;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import devops.serenity.ProductVerificationPage;
import devops.serenity.iRobot_AccessoriesPage;
import devops.serenity.iRobot_HomePage;
import devops.serenity.iRobot_ProductInfoPage;
import devops.serenity.iRobot_ViewCartPage;
import devops.utils.loginTable;
import net.thucydides.core.annotations.Managed;
import net.thucydides.core.annotations.Steps;

public class iRobot_Steps {

	/*
	 * Author: Prajesh Jain Created On: 12/03/2019 Description: Code for New FXM
	 * Header
	 */
//******************* instances of steps defined for creating end to end flow for iRobot *****************************************//
	@Steps
	iRobot_HomePage iHomePageSteps;

	@Steps
	iRobot_ProductInfoPage iProductInfoPageSteps;

	@Steps
	iRobot_AccessoriesPage accessoriesPage;

	@Steps
	iRobot_ViewCartPage viewCartPage;

	@Steps
	iRobot_HomePage newHomePage;

	@Steps
	ProductVerificationPage productVerificationPage;

	@Managed
	WebDriver driver;

//************************ instances of steps defined for creating end to end flow for iRobot ******************************************//

	// # Method for selecting location
	@Given("^user provides location (.*) to select the irobot store$")
	public void user_provides_location_to_select_the_irobot_store(String location) throws InterruptedException {
		// Write code here that turns the phrase above into concrete actions
		iHomePageSteps.openPage(location);

	}

	// # Method for selecting category and product in the new Fxm Header
	@Given("^user clicks on tab (.*) and selects a category (.*) and product (.*) based on the location (.*)$")
	public void user_clicks_on_tab_and_selects_a_category_and_product_based_on_the_location(String tab,
			String category, String product, String location) throws InterruptedException {
		// Write code here that turns the phrase above into concrete actions
		newHomePage.selProduct(tab, category, product, location);
	}

	// # Method for verifying the title of the pages
	@Then("^verify the title of the page (.*)$")
	public void verify_the_title_of_the_page(String title) throws InterruptedException {
		// Write code here that turns the phrase above into concrete actions
		productVerificationPage.VerifyTitle(title);
	}

	//# Method for accessories Tab	
	@Then("^user selects a productCategory (.*) on accessories page$")
	public void user_selects_a_productCategory_on_accessories_page(String productCtg) throws InterruptedException  {
		// Write code here that turns the phrase above into concrete actions
		accessoriesPage.selProductCategory(productCtg);
	}

	//# Method to add multiple 
	@When("^user added quant (.*) to the cart$")
	public void user_added_quant_to_the_cart(String quant) throws InterruptedException {
		// Write code here that turns the phrase above into concrete actions
		iProductInfoPageSteps.selQuantity(quant);

	}
	
	// # Method Step for country selector
	@Given("^user clicks on the country selector and select the country (.*)$")
	public void user_clicks_on_the_country_selector_and_select_the_country(String country) throws InterruptedException{
	    // Write code here that turns the phrase above into concrete actions
		iHomePageSteps.countrySelector(country);
	}
	
	
	//# Method for footer email Sign up
	@Given("^user fill the emailId (.*) in the email sign up form$")
	public void user_fill_the_emailId_in_the_email_sign_up_form(String email) throws InterruptedException {
	    // Write code here that turns the phrase above into concrete actions
	  iHomePageSteps.footerEmailSignUp(email);
	}
	
	
	//# Method for Type Ahead Search
	@Given("^click on the search icon and enter the text(.*) to search$")
	public void click_on_the_search_icon_and_enter_the_text_to_search(String text) throws InterruptedException{
	    // Write code here that turns the phrase above into concrete actions
	   iHomePageSteps.search(text);
	}


	//# Method to verfiy the search result
	@Given("^verify the search list gets populated$")
	public void verify_the_search_list_gets_populated() throws InterruptedException  {
	    // Write code here that turns the phrase above into concrete actions
		  iHomePageSteps.verifySearchList();
	}
	
	
	@Given("^user clicks on the cart icon to hide the mini cart$")
	public void user_clicks_on_the_cart_icon_to_hide_the_mini_cart() throws InterruptedException {
		// Write code here that turns the phrase above into concrete actions
		iProductInfoPageSteps.hideMiniCart();
	}

	
	//# Method for comparing products
	@Given("^user clicks on tab (.*) and click on compare (.*) based on the location (.*)$")
	public void user_clicks_on_tab_and_click_on_compare_based_on_the_location(String tab, String product, String location) throws InterruptedException {
	    // Write code here that turns the phrase above into concrete actions
	   iHomePageSteps.compareProducts(tab, product, location);
	}
	@Given("^user click on view cart button$")
	public void user_click_on_view_cart_button() throws InterruptedException {
		// Write code here that turns the phrase above into concrete actions
		iProductInfoPageSteps.clkViewCart();

	}
	
	//# Method to add product to the cart
	@Given("^add product(.*) to the cart$")
	public void add_product_to_the_cart(String product)  throws InterruptedException {
	    // Write code here that turns the phrase above into concrete actions
	   iProductInfoPageSteps.addProduct(product);
	}

	
	//# Method for checking product added to the minicart
	@Then("^verify the product is added to the miniCart$")
	public void verify_the_product_is_added_to_the_miniCart() throws InterruptedException {
	    // Write code here that turns the phrase above into concrete actions
	    iHomePageSteps.miniCart();
	}

	@Given("^user must be able to apply promo (.*) code$")
	public void user_must_be_able_to_apply_promo_code(String promoCode) throws InterruptedException {
		// Write code here that turns the phrase above into concrete actions
		viewCartPage.applyCoupon(promoCode);

	}

	@Given("^verify coupon is applied successfully$")
	public void verify_coupon_is_applied_successfully() throws InterruptedException {
		// Write code here that turns the phrase above into concrete actions
		viewCartPage.verifySuccessMessage();
	}

	@Given("^user click on checkout button on view cart page$")
	public void user_click_on_checkout_button_on_view_cart_page() throws InterruptedException {
		// Write code here that turns the phrase above into concrete actions
		viewCartPage.cartCheckout();
	}

	@When("^user click on checkout$")
	public void user_click_on_checkout() throws InterruptedException {
		// Write code here that turns the phrase above into concrete actions
		iProductInfoPageSteps.proceedCheckout();

	}

	@Given("^checkout as a guest user$")
	public void checkout_as_a_guest_user() throws InterruptedException {
		// Write code here that turns the phrase above into concrete actions
		iProductInfoPageSteps.proceedCheckout();
		iProductInfoPageSteps.guestCheckout();

	}

	@When("^user provides returning customer information$")
	public void user_provides_returning_customer_information(DataTable table) throws InterruptedException {
		String email = null;
		String password = null;

		List<loginTable> values = new ArrayList<loginTable>();
		values = table.asList(loginTable.class);

		for (loginTable value : values) {
			email = value.email;
			password = value.password;
		}

		iProductInfoPageSteps.loginReturningCust(email, password);

	}

}